XeLaTeX-проект курсовой работы.

Сборка: xelatex main.tex (два раза для корректного оглавления и ссылок).
Основной файл: main.tex
Рисунки: images/

Примечание: проект подготовлен из КурсачLMM.docx по шаблону tim_coursework_template-main/XeLaTeX.